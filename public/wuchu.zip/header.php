<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="/public/css/style.css" />
</head>
<body>
<div class="wrap">
    <div class="header">
        <div class="header-main">
            <div class="logo"><a href="index.html"><img src="img/logo.png" /></a></div>
            <div class="user" align="center">
                <a href="login.php"><img src="img/user.png" /><span style="color:black;font-size:15px;">未登录</span></a>
            </div>
        </div>
    </div>
    <!--<div class="huawen"></div>-->
    <div class="menu">
		<ul>
            <li class="mori"><a href="mori.php?id=1"></a></li>
			<li class="temege"><a href="temege.php?id=1"></a></li>
            <li class="uher"><a href="uher.php?id=1"></a></li>
			<li class="honi"><a href="honi.php?id=1"></a></li>
			<li class="yimaga"><a href="yimaga.php?id=1"></a></li>	
		</ul>
	</div>
	<div class="content">
		